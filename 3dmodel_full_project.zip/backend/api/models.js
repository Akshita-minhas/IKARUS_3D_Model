import axios from 'axios';

const API_URL = 'http://localhost:5000';

// Fetch models from backend
export const fetchModels = async () => {
  try {
    const response = await axios.get(`${API_URL}/models`);
    return response.data;
  } catch (error) {
    console.error('Error fetching models:', error);
    return [];
  }
};

// Upload a new model to backend
export const uploadModel = async (name, url, description = '') => {
  try {
    const response = await axios.post(`${API_URL}/upload`, {
      name,
      url,
      description,
    });
    return response.data;
  } catch (error) {
    console.error('Error uploading model:', error);
    return null;
  }
};