require('dotenv').config();
const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
const path = require('path');

// Initialize Firebase
const serviceAccount = require(path.join(__dirname, 'serviceAccountKey.json'));
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: 'your-firebase-app.appspot.com', // Replace with actual Firebase Storage bucket
});
const db = admin.firestore();

const app = express();
app.use(express.json());
app.use(cors());

// Mock Data (To be replaced with Firestore fetch)
const models = [
  { id: '1', name: 'Air Jordan 1 Low', url: 'https://d3ecp0do4cosz.cloudfront.net/assets/3Dmodels/nullAir%20Jordan%201%20Low-v-0-v-.glb' },
  { id: '2', name: 'Jordan Hex Mule', url: 'https://d3ecp0do4cosz.cloudfront.net/assets/3Dmodels/nullJordan%20Hex%20Mule-v-0-v-.glb' },
  { id: '3', name: 'Nike Air Max 97 SE', url: 'https://d3ecp0do4cosz.cloudfront.net/assets/3Dmodels/nullNike%20Air%20Max%2097%20SE-v-0-v-.glb' },
  { id: '4', name: 'Nike Oneonta Next Nature', url: 'https://d3ecp0do4cosz.cloudfront.net/assets/3Dmodels/nullNike%20Oneonta%20Next%20Nature-v-0-v-.glb' },
  { id: '5', name: 'True Blue and Copper', url: 'https://d3ecp0do4cosz.cloudfront.net/assets/3Dmodels/nullTrue%20Blue%20and%20Copper-v-0-v-.glb' }
];

// GET /models - Fetch models from Firestore
app.get('/models', async (req, res) => {
  try {
    const snapshot = await db.collection('models').get();
    if (snapshot.empty) return res.json(models); // Return mock data if Firestore is empty
    const modelList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.json(modelList);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch models' });
  }
});

// POST /upload - Upload a new model to Firestore
app.post('/upload', async (req, res) => {
  const { name, url, description } = req.body;
  if (!name || !url) return res.status(400).json({ error: 'Name and URL are required' });
  try {
    const docRef = await db.collection('models').add({
      name,
      url,
      description: description || '',
      uploadDate: new Date().toISOString()
    });
    res.json({ id: docRef.id, message: 'Model uploaded successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to upload model' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));