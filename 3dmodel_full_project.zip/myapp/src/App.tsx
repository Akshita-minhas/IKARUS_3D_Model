import React, { useEffect, useState } from 'react';
import ModelViewer from './components/ModelViewer';
import SearchBar from './components/SearchBar';
import ModelCard from './components/ModelCard';
import { fetchModels, searchModels } from './api/models';
import { Model3D } from './types';
import { Cuboid as Cube3D, Loader2 } from 'lucide-react';

function App() {
  const [models, setModels] = useState<Model3D[]>([]);
  const [filteredModels, setFilteredModels] = useState<Model3D[]>([]);
  const [selectedModel, setSelectedModel] = useState<Model3D | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSearching, setIsSearching] = useState(false);

  // Fetch models on component mount
  useEffect(() => {
    const getModels = async () => {
      setIsLoading(true);
      try {
        const data = await fetchModels();
        setModels(data);
        setFilteredModels(data);
        
        // Set the first model as selected by default
        if (data.length > 0) {
          setSelectedModel(data[0]);
        }
      } catch (error) {
        console.error('Error fetching models:', error);
      } finally {
        setIsLoading(false);
      }
    };

    getModels();
  }, []);

  // Handle search
  const handleSearch = async (query: string) => {
    setIsSearching(true);
    try {
      if (query.trim() === '') {
        setFilteredModels(models);
      } else {
        const results = await searchModels(query);
        setFilteredModels(results);
      }
    } catch (error) {
      console.error('Error searching models:', error);
    } finally {
      setIsSearching(false);
    }
  };

  // Handle model selection
  const handleModelSelect = (model: Model3D) => {
    setSelectedModel(model);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Cube3D className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-800">3D Model Viewer</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Search Bar */}
        <div className="mb-8">
          <SearchBar onSearch={handleSearch} />
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Model List */}
            <div className="lg:col-span-1 bg-gray-50 p-4 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Available Models</h2>
              
              {isSearching ? (
                <div className="flex items-center justify-center h-32">
                  <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
                </div>
              ) : filteredModels.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No models found. Try a different search term.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 max-h-[600px] overflow-y-auto pr-2">
                  {filteredModels.map((model) => (
                    <ModelCard
                      key={model.id}
                      model={model}
                      isSelected={selectedModel?.id === model.id}
                      onClick={() => handleModelSelect(model)}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* 3D Viewer */}
            <div className="lg:col-span-2">
              <div className="bg-white p-4 rounded-lg shadow-md">
                <h2 className="text-xl font-semibold mb-4">
                  {selectedModel ? selectedModel.name : 'Select a model'}
                </h2>
                <div className="h-[600px] w-full">
                  {selectedModel ? (
                    <ModelViewer 
                      modelUrl={selectedModel.url} 
                      isLoading={isLoading} 
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-200 rounded-lg">
                      <p className="text-gray-600">Select a model to view</p>
                    </div>
                  )}
                </div>
                {selectedModel && (
                  <div className="mt-4">
                    <p className="text-gray-700">{selectedModel.description}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white shadow-inner mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-gray-600">
            © 2025 3D Model Viewer. All models are for demonstration purposes.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;