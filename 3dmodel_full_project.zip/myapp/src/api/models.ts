import { Model3D } from '../types';

// Mock API service for fetching 3D models
// In a real application, this would be replaced with actual API calls

// Sample 3D models data with publicly accessible URLs
const models: Model3D[] = [
  {
    id: '1',
    name: 'Flight Helmet',
    description: 'A detailed flight helmet model',
    url: 'https://threejs.org/examples/models/gltf/FlightHelmet/glTF/FlightHelmet.gltf',
    thumbnail: 'https://images.unsplash.com/photo-1582845512747-e42001c95638?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'
  },
  {
    id: '2',
    name: 'Damaged Helmet',
    description: 'A damaged sci-fi helmet',
    url: 'https://threejs.org/examples/models/gltf/DamagedHelmet/glTF/DamagedHelmet.gltf',
    thumbnail: 'https://images.unsplash.com/photo-1503792501406-2c40da09e1e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'
  },
  {
    id: '3',
    name: 'Little Shiba',
    description: 'A cute Shiba Inu dog model',
    url: 'https://threejs.org/examples/models/gltf/LittlestTokyo.glb',
    thumbnail: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'
  },
  {
    id: '4',
    name: 'Parrot',
    description: 'A colorful parrot model',
    url: 'https://threejs.org/examples/models/gltf/Parrot.glb',
    thumbnail: 'https://images.unsplash.com/photo-1501720804996-ae99f4a3f00a?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'
  },
  {
    id: '5',
    name: 'Flamingo',
    description: 'A graceful flamingo model',
    url: 'https://threejs.org/examples/models/gltf/Flamingo.glb',
    thumbnail: 'https://images.unsplash.com/photo-1497206365907-f5e630693df0?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'
  }
];

// Function to fetch all models
export const fetchModels = async (): Promise<Model3D[]> => {
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(models);
    }, 500);
  });
};

// Function to search models by name
export const searchModels = async (query: string): Promise<Model3D[]> => {
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      const filteredModels = models.filter(model => 
        model.name.toLowerCase().includes(query.toLowerCase())
      );
      resolve(filteredModels);
    }, 300);
  });
};

// Function to get a model by ID
export const getModelById = async (id: string): Promise<Model3D | undefined> => {
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      const model = models.find(model => model.id === id);
      resolve(model);
    }, 200);
  });
};