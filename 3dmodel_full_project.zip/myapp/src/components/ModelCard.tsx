import React from 'react';
import { Model3D } from '../types';

interface ModelCardProps {
  model: Model3D;
  isSelected: boolean;
  onClick: () => void;
}

const ModelCard: React.FC<ModelCardProps> = ({ model, isSelected, onClick }) => {
  return (
    <div 
      className={`p-4 rounded-lg cursor-pointer transition-all duration-200 ${
        isSelected 
          ? 'bg-blue-100 border-2 border-blue-500' 
          : 'bg-white hover:bg-gray-100 border-2 border-transparent'
      }`}
      onClick={onClick}
    >
      <div className="aspect-square w-full overflow-hidden rounded-md mb-2">
        <img 
          src={model.thumbnail} 
          alt={model.name} 
          className="w-full h-full object-cover"
        />
      </div>
      <h3 className="font-medium text-lg">{model.name}</h3>
      <p className="text-gray-600 text-sm">{model.description}</p>
    </div>
  );
};

export default ModelCard;