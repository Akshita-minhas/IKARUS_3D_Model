import React, { useRef, useState, useEffect, Suspense as ReactSuspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, useGLTF, Environment, Center, PerspectiveCamera, Html } from '@react-three/drei';
import { Suspense } from 'react';
import { Loader2 } from 'lucide-react';
import * as THREE from 'three';

// Custom error boundary for model loading
class ModelErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode; fallback: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: any) {
    console.error("Error in model component:", error);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

// Model component that loads and displays a 3D model
function Model({ url }: { url: string }) {
  const [error, setError] = useState<string | null>(null);
  const { scene, animations } = useGLTF(url, undefined, (e) => {
    console.error("GLTF loading error:", e);
    setError(e.message || "Failed to load model");
  });
  
  const [sceneReady, setSceneReady] = useState(false);
  
  useEffect(() => {
    if (scene) {
      // Reset rotation and position
      scene.rotation.set(0, 0, 0);
      scene.position.set(0, 0, 0);
      
      // Calculate bounding box to determine appropriate scale
      const box = new THREE.Box3().setFromObject(scene);
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z);
      const scale = maxDim > 0 ? 2 / maxDim : 1;
      
      // Apply scale
      scene.scale.set(scale, scale, scale);
      
      setSceneReady(true);
    }
  }, [scene, url]);
  
  if (error) {
    return (
      <Html center>
        <div className="bg-red-900 bg-opacity-80 p-4 rounded-lg text-white">
          <p>Error loading model: {error}</p>
        </div>
      </Html>
    );
  }
  
  if (!sceneReady) {
    return null;
  }
  
  return <primitive object={scene} />;
}

// Loading placeholder component
function LoadingPlaceholder() {
  return (
    <Center>
      <mesh>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="gray" wireframe />
      </mesh>
      <Html center>
        <div className="text-white bg-black bg-opacity-50 p-2 rounded">
          Loading model...
        </div>
      </Html>
    </Center>
  );
}

// Error fallback component
function ErrorFallback() {
  return (
    <Center>
      <Html center>
        <div className="bg-red-900 bg-opacity-80 p-4 rounded-lg text-white">
          <p>Failed to load model</p>
          <p className="text-sm mt-2">Please try another model</p>
        </div>
      </Html>
    </Center>
  );
}

interface ModelViewerProps {
  modelUrl: string;
  isLoading: boolean;
}

const ModelViewer: React.FC<ModelViewerProps> = ({ modelUrl, isLoading }) => {
  const controlsRef = useRef(null);
  const [modelError, setModelError] = useState<string | null>(null);
  const [isModelLoading, setIsModelLoading] = useState(false);

  // Reset error state when model URL changes
  useEffect(() => {
    setModelError(null);
    setIsModelLoading(true);
    
    // Preload the model to check if it's valid
    const preloadModel = async () => {
      try {
        const response = await fetch(modelUrl);
        if (!response.ok) {
          throw new Error(`HTTP error ${response.status}`);
        }
        setIsModelLoading(false);
      } catch (error) {
        console.error("Error preloading model:", error);
        setModelError(`Failed to load model: Network error`);
        setIsModelLoading(false);
      }
    };
    
    preloadModel();
    
    // Clear GLTF cache when changing models to prevent issues
    return () => {
      useGLTF.clear(modelUrl);
    };
  }, [modelUrl]);

  return (
    <div className="w-full h-full rounded-lg overflow-hidden bg-gray-900">
      {isLoading || isModelLoading ? (
        <div className="w-full h-full flex items-center justify-center">
          <Loader2 className="w-12 h-12 text-white animate-spin" />
        </div>
      ) : modelError ? (
        <div className="w-full h-full flex items-center justify-center flex-col p-4">
          <p className="text-red-400 text-center mb-2">⚠️ {modelError}</p>
          <p className="text-gray-300 text-center text-sm">Try selecting a different model</p>
        </div>
      ) : (
        <Canvas shadows camera={{ position: [0, 0, 5], fov: 50 }}>
          <color attach="background" args={['#1a1a2e']} />
          <PerspectiveCamera makeDefault position={[0, 0, 5]} />
          <ambientLight intensity={0.5} />
          <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
          <ReactSuspense fallback={null}>
            <ModelErrorBoundary fallback={<ErrorFallback />}>
              <Suspense fallback={<LoadingPlaceholder />}>
                <Center>
                  <Model url={modelUrl} />
                </Center>
                <Environment preset="city" />
              </Suspense>
            </ModelErrorBoundary>
          </ReactSuspense>
          <OrbitControls 
            ref={controlsRef}
            enablePan={true}
            enableZoom={true}
            enableRotate={true}
            minDistance={1}
            maxDistance={10}
            autoRotate={false}
            dampingFactor={0.05}
          />
        </Canvas>
      )}
    </div>
  );
};

export default ModelViewer;