export interface Model3D {
  id: string;
  name: string;
  description: string;
  url: string;
  thumbnail: string;
}